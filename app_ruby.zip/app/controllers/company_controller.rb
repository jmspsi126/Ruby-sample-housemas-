class CompanyController < ApplicationController
  layout 'company'

  def index
  end

end
