module HomeGaugeHelper
end
