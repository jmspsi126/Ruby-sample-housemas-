module FranchiseHelper
end
